module com.example.dataestructures_javafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.dataestructures_javafx to javafx.fxml;
    exports com.example.dataestructures_javafx;
}