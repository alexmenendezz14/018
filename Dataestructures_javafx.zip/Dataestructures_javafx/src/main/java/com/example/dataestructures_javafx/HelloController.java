package com.example.dataestructures_javafx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.*;

public class HelloController {
    @FXML
    private TextField txt_datos;
    @FXML
    private ListView<String> listView;
    @FXML
    private ComboBox<String> comboJugadores;
    @FXML
    private TextField txtGoles;
    @FXML
    private Button btnAgregar;
    @FXML
    private Button btnMostrarGoles;
    @FXML
    private Button btnClasificacion;
    @FXML
    private Label lblJornada;
    @FXML
    private ListView<String> listViewClasificacion;
    @FXML
    private TextField txtNuevoJugador;

    private int jornada = 1;
    private Map<String, Integer> golesJugadores = new HashMap<>();
    private Map<String, Integer> totalGoles = new HashMap<>();

    @FXML
    public void initialize() {
        // Configurar los jugadores en el ComboBox
        ObservableList<String> jugadores = FXCollections.observableArrayList(
                "Jude Bellingham", "Sorlohok", "Morata", "Vinicius"
        );
        comboJugadores.setItems(jugadores);

        // Mostrar la jornada inicial
        lblJornada.setText("Jornada: " + jornada);
    }

    @FXML
    protected void AgregarAl() {
        String nuevoDato = txt_datos.getText().trim();
        if (!nuevoDato.isEmpty()) {
            listView.getItems().add(nuevoDato);
            txt_datos.clear();
        }
    }

    @FXML
    protected void mostrarAlOrdenado() {
        ObservableList<String> items = FXCollections.observableArrayList(listView.getItems());
        Collections.sort(items);
        listView.setItems(items);
    }

    @FXML
    protected void agregarGoles() {
        String jugador = comboJugadores.getValue();
        int goles = Integer.parseInt(txtGoles.getText());

        // Actualizar el total de goles del jugador
        if (golesJugadores.containsKey(jugador)) {
            int golesAnteriores = golesJugadores.get(jugador);
            golesJugadores.put(jugador, golesAnteriores + goles);
        } else {
            golesJugadores.put(jugador, goles);
        }

        // Actualizar el total de goles de todos los jugadores
        if (totalGoles.containsKey(jugador)) {
            int golesAnteriores = totalGoles.get(jugador);
            totalGoles.put(jugador, golesAnteriores + goles);
        } else {
            totalGoles.put(jugador, goles);
        }
    }

    @FXML
    protected void mostrarGoles() {
        String jugador = comboJugadores.getValue();
        int goles = golesJugadores.getOrDefault(jugador, 0);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Goles de " + jugador);
        alert.setHeaderText(null);
        alert.setContentText(jugador + " ha marcado " + goles + " goles.");
        alert.showAndWait();
    }

    @FXML
    protected void mostrarClasificacion() {
        // Utilizar un TreeMap para ordenar los jugadores según la cantidad total de goles marcados
        Map<String, Integer> clasificacion = new TreeMap<>((jugador1, jugador2) -> {
            int goles1 = totalGoles.get(jugador1);
            int goles2 = totalGoles.get(jugador2);
            return goles2 - goles1;
        });

        clasificacion.putAll(totalGoles);

        // Mostrar los jugadores en orden descendente
        ObservableList<String> items = FXCollections.observableArrayList();
        for (Map.Entry<String, Integer> entry : clasificacion.entrySet()) {
            String jugador = entry.getKey();
            int goles = entry.getValue();
            items.add(jugador + ": " + goles + " goles");
        }
        listViewClasificacion.setItems(items);
    }

    @FXML
    protected void avanzarJornada() {
        jornada++;
        lblJornada.setText("Jornada: " + jornada);
    }

    @FXML
    protected void agregarNuevoJugador() {
        String nuevoJugador = txtNuevoJugador.getText().trim();
        if (!nuevoJugador.isEmpty() && !comboJugadores.getItems().contains(nuevoJugador)) {
            comboJugadores.getItems().add(nuevoJugador);
            txtNuevoJugador.clear();
        }
    }
}
